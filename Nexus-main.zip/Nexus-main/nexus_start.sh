#!/bin/bash
echo -e "\033[96m◈ Starting NEXUS...\033[0m"
cd "$(dirname "$0")"
python3 server.py
