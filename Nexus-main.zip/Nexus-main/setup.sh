#!/bin/bash
# ╔══════════════════════════════════════════╗
# ║   NEXUS Setup Script — macOS            ║
# ╚══════════════════════════════════════════╝
set -e

CYAN='\033[96m'; GOLD='\033[93m'; GREEN='\033[92m'; RED='\033[91m'; DIM='\033[2m'; RESET='\033[0m'

logo() {
echo -e "${CYAN}"
cat << 'EOF'
  ███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗
  ██╔╝   ╚═╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝
    SETUP — macOS
EOF
echo -e "${RESET}"
}

step() { echo -e "\n${GOLD}◈ $1${RESET}"; }
ok()   { echo -e "  ${GREEN}✓ $1${RESET}"; }
info() { echo -e "  ${DIM}$1${RESET}"; }
err()  { echo -e "  ${RED}✕ $1${RESET}"; exit 1; }

logo

# ── Python check ──────────────────────────
step "Checking Python 3.8+"
if ! command -v python3 &>/dev/null; then
  err "Python 3 not found. Install from https://python3.org"
fi
PYVER=$(python3 -c 'import sys; print(sys.version_info[:2])')
ok "Python OK: $(python3 --version)"

# ── pip deps ──────────────────────────────
step "Installing Python dependencies"
pip3 install qrcode[pil] pillow --quiet
ok "qrcode, pillow installed"

# ── Node / localtunnel (for internet access) ──
step "Checking Node.js + localtunnel"
if command -v npm &>/dev/null; then
  npm install -g localtunnel --quiet 2>/dev/null && ok "localtunnel installed" || info "localtunnel install skipped (run: npm install -g localtunnel)"
else
  info "Node.js not found — install from https://nodejs.org for internet tunnel support"
fi

# ── Generate self-signed TLS cert ─────────
step "Generating TLS certificate (for HTTPS)"
if [ ! -f cert.pem ]; then
  openssl req -x509 -newkey rsa:2048 -keyout key.pem -out cert.pem -days 365 -nodes \
    -subj "/C=US/ST=Stark/L=Malibu/O=NEXUS/CN=localhost" 2>/dev/null
  ok "cert.pem + key.pem generated (365 days)"
else
  ok "cert.pem already exists"
fi

# ── macOS Firewall hint ────────────────────
step "macOS Firewall note"
info "If prompted by macOS, click ALLOW to let NEXUS accept connections."
info "Or run:  sudo /usr/libexec/ApplicationFirewall/socketfilterfw --add $(which python3)"

# ── Create launch script ──────────────────
step "Creating launch alias"
cat > nexus_start.sh << 'LAUNCH'
#!/bin/bash
echo -e "\033[96m◈ Starting NEXUS...\033[0m"
cd "$(dirname "$0")"
python3 server.py
LAUNCH
chmod +x nexus_start.sh
ok "nexus_start.sh ready"

# ── LaunchAgent for auto-start at login ───
step "Creating macOS LaunchAgent (optional auto-start)"
PLIST=~/Library/LaunchAgents/com.nexus.fileserver.plist
SCRIPT_DIR=$(pwd)
cat > "$PLIST" << PLIST_EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.nexus.fileserver</string>
  <key>ProgramArguments</key>
  <array>
    <string>$(which python3)</string>
    <string>${SCRIPT_DIR}/server.py</string>
  </array>
  <key>WorkingDirectory</key><string>${SCRIPT_DIR}</string>
  <key>RunAtLoad</key><false/>
  <key>KeepAlive</key><false/>
  <key>StandardOutPath</key><string>${SCRIPT_DIR}/nexus.log</string>
  <key>StandardErrorPath</key><string>${SCRIPT_DIR}/nexus.log</string>
</dict>
</plist>
PLIST_EOF
ok "LaunchAgent written to ~/Library/LaunchAgents/"
info "To enable auto-start: launchctl load $PLIST"
info "To disable:           launchctl unload $PLIST"

echo ""
echo -e "${CYAN}╔═══════════════════════════════════════╗${RESET}"
echo -e "${CYAN}║   NEXUS SETUP COMPLETE                ║${RESET}"
echo -e "${CYAN}╠═══════════════════════════════════════╣${RESET}"
echo -e "${CYAN}║${RESET}                                       ${CYAN}║${RESET}"
echo -e "${CYAN}║${RESET}  ${GOLD}1. Edit server.py${RESET}                    ${CYAN}║${RESET}"
echo -e "${CYAN}║${RESET}     ${DIM}Change secret_key + password${RESET}      ${CYAN}║${RESET}"
echo -e "${CYAN}║${RESET}                                       ${CYAN}║${RESET}"
echo -e "${CYAN}║${RESET}  ${GOLD}2. Launch server${RESET}                     ${CYAN}║${RESET}"
echo -e "${CYAN}║${RESET}     ${DIM}./nexus_start.sh${RESET}                   ${CYAN}║${RESET}"
echo -e "${CYAN}║${RESET}                                       ${CYAN}║${RESET}"
echo -e "${CYAN}║${RESET}  ${GOLD}3. Open browser${RESET}                      ${CYAN}║${RESET}"
echo -e "${CYAN}║${RESET}     ${DIM}http://localhost:8443${RESET}              ${CYAN}║${RESET}"
echo -e "${CYAN}║${RESET}                                       ${CYAN}║${RESET}"
echo -e "${CYAN}╚═══════════════════════════════════════╝${RESET}"
echo ""
