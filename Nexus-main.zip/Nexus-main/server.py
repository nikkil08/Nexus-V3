#!/usr/bin/env python3
"""
███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗
████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝
██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗
██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║
██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║
╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝
NEXUS Personal File Server — v2.1
By Nikkil Prithivn
"""

import os, sys, json, time, hashlib, hmac, mimetypes, threading, subprocess
import shutil, socket, qrcode, io
from pathlib import Path
from datetime import datetime, timedelta
from functools import wraps
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote

# ──────────────────────────────────────────────
#  CONFIG  (edit these before first launch)
# ──────────────────────────────────────────────
CONFIG = {
    "serve_dir":  str(Path.home()),          # root directory to expose
    "port":       8443,                       # HTTPS port
    "host":       "0.0.0.0",
    "secret_key": "just a rather very intelligent system",
    "token_ttl":  3600 * 12,                 # session lifetime (seconds)
    "password":   "jarv1s",    # login password
    "max_upload": 4 * 1024 ** 3,            # 4 GB
    "use_ssl":    False,                      # set True + run gen_cert() first
    "tunnel":     False,                      # set True to auto-launch localtunnel
}

NEXUS_VERSION = "2.1"
START_TIME = time.time()
ACTIVE_SESSIONS: dict = {}

# ──────────────────────────────────────────────
#  COLOUR TERMINAL OUTPUT
# ──────────────────────────────────────────────
C = {
    "cyan":   "\033[96m", "gold":  "\033[93m", "green": "\033[92m",
    "red":    "\033[91m", "dim":   "\033[2m",  "bold":  "\033[1m",
    "reset":  "\033[0m",
}
def log(level: str, msg: str):
    ts = datetime.now().strftime("%H:%M:%S")
    icons = {"INFO":"◈","OK":"✓","WARN":"⚠","ERR":"✕","BEAM":"⬆","IN":"⬇"}
    cols  = {"INFO":C["cyan"],"OK":C["green"],"WARN":C["gold"],"ERR":C["red"],
             "BEAM":C["gold"],"IN":C["cyan"]}
    print(f"{C['dim']}{ts}{C['reset']} {cols.get(level,C['cyan'])}{icons.get(level,'·')}{C['reset']} {msg}")

# ──────────────────────────────────────────────
#  AUTH
# ──────────────────────────────────────────────
def make_token(user: str) -> str:
    ts  = str(int(time.time()))
    sig = hmac.new(CONFIG["secret_key"].encode(), f"{user}:{ts}".encode(), hashlib.sha256).hexdigest()
    token = f"{user}:{ts}:{sig}"
    ACTIVE_SESSIONS[token] = {"user": user, "created": ts, "ip": ""}
    return token

def verify_token(token: str) -> bool:
    if not token or token not in ACTIVE_SESSIONS:
        return False
    _, ts, _ = token.split(":", 2)
    return (time.time() - int(ts)) < CONFIG["token_ttl"]

# ──────────────────────────────────────────────
#  PATH HELPERS
# ──────────────────────────────────────────────
ROOT = Path(CONFIG["serve_dir"]).resolve()

def safe_path(rel: str) -> Path | None:
    """Resolve a user-supplied path, reject traversal attacks."""
    try:
        p = (ROOT / unquote(rel.lstrip("/"))).resolve()
        return p if str(p).startswith(str(ROOT)) else None
    except Exception:
        return None

def human_size(n: int) -> str:
    for unit in ["B","KB","MB","GB","TB"]:
        if n < 1024: return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"

def file_info(p: Path) -> dict:
    stat = p.stat()
    return {
        "name":     p.name,
        "path":     str(p.relative_to(ROOT)),
        "is_dir":   p.is_dir(),
        "size":     stat.st_size,
        "size_h":   human_size(stat.st_size),
        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
        "ext":      p.suffix.lower(),
        "mime":     mimetypes.guess_type(p.name)[0] or "application/octet-stream",
    }

# ──────────────────────────────────────────────
#  BEAUTIFUL HTML UI (served at /)
# ──────────────────────────────────────────────
def render_ui() -> str:
    """Return the full NEXUS web interface HTML."""
    return open(Path(__file__).parent / "ui.html").read() if (
        Path(__file__).parent / "ui.html").exists() else "<h1>NEXUS — UI not found. Run setup.sh first.</h1>"

# ──────────────────────────────────────────────
#  REQUEST HANDLER
# ──────────────────────────────────────────────
class NexusHandler(BaseHTTPRequestHandler):
    server_version = f"NEXUS/{NEXUS_VERSION}"

    def log_message(self, fmt, *args):
        pass  # we handle logging ourselves

    def send_json(self, data: dict, code: int = 200):
        body = json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(body))
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def send_html(self, html: str, code: int = 200):
        body = html.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", len(body))
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")

    def _token(self) -> str | None:
        auth = self.headers.get("Authorization", "")
        if auth.startswith("Bearer "): return auth[7:]
        # also check cookie
        cookie = self.headers.get("Cookie", "")
        for c in cookie.split(";"):
            k, _, v = c.strip().partition("=")
            if k == "nexus_token": return v
        return None

    def _authed(self) -> bool:
        return verify_token(self._token() or "")

    # ── OPTIONS (CORS preflight) ──
    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    # ── GET ──
    def do_GET(self):
        parsed = urlparse(self.path)
        path   = parsed.path.rstrip("/") or "/"
        qs     = parse_qs(parsed.query)

        # Login page
        if path == "/":
            self.send_html(render_ui())
            return

        # Favicon
        if path == "/favicon.ico":
            self.send_response(204); self.end_headers(); return

        # QR code for local access
        if path == "/api/qr":
            if not self._authed():
                self.send_json({"error":"unauthorized"}, 401); return
            ip   = socket.gethostbyname(socket.gethostname())
            url  = f"http://{ip}:{CONFIG['port']}"
            qr   = qrcode.make(url)
            buf  = io.BytesIO()
            qr.save(buf, format="PNG")
            img  = buf.getvalue()
            self.send_response(200)
            self.send_header("Content-Type","image/png")
            self.send_header("Content-Length", len(img))
            self._cors(); self.end_headers()
            self.wfile.write(img)
            return

        # Status / stats
        if path == "/api/status":
            if not self._authed():
                self.send_json({"error":"unauthorized"}, 401); return
            disk = shutil.disk_usage(str(ROOT))
            self.send_json({
                "status":   "ONLINE",
                "version":  NEXUS_VERSION,
                "uptime":   int(time.time() - START_TIME),
                "sessions": len(ACTIVE_SESSIONS),
                "disk": {
                    "total": disk.total,
                    "used":  disk.used,
                    "free":  disk.free,
                    "total_h": human_size(disk.total),
                    "free_h":  human_size(disk.free),
                },
                "serve_dir": str(ROOT),
            }); return

        # List directory
        if path == "/api/ls":
            if not self._authed():
                self.send_json({"error":"unauthorized"}, 401); return
            rel  = qs.get("path",[""])[0]
            p    = safe_path(rel)
            if not p or not p.exists():
                self.send_json({"error":"not found"}, 404); return
            if p.is_file():
                self.send_json({"error":"not a directory"}, 400); return
            entries = sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
            self.send_json({
                "path":    str(p.relative_to(ROOT)),
                "entries": [file_info(e) for e in entries[:500]],
            }); return

        # Download file
        if path == "/api/get":
            if not self._authed():
                self.send_json({"error":"unauthorized"}, 401); return
            rel  = qs.get("path",[""])[0]
            p    = safe_path(rel)
            if not p or not p.is_file():
                self.send_json({"error":"not found"}, 404); return
            log("IN", f"DOWNLOAD  {p.name}  ({human_size(p.stat().st_size)})  ← {self.client_address[0]}")
            mime = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
            size = p.stat().st_size
            self.send_response(200)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", size)
            self.send_header("Content-Disposition", f'attachment; filename="{p.name}"')
            self._cors(); self.end_headers()
            with open(p, "rb") as f:
                shutil.copyfileobj(f, self.wfile)
            return

        self.send_json({"error":"not found"}, 404)

    # ── POST ──
    def do_POST(self):
        parsed = urlparse(self.path)
        path   = parsed.path

        # ── LOGIN ──
        if path == "/api/login":
            length = int(self.headers.get("Content-Length", 0))
            body   = json.loads(self.rfile.read(length))
            if body.get("password") == CONFIG["password"]:
                token = make_token("operator")
                log("OK", f"AUTH SUCCESS — session opened for {self.client_address[0]}")
                self.send_response(200)
                self.send_header("Set-Cookie", f"nexus_token={token}; Path=/; SameSite=Strict")
                self.send_header("Content-Type", "application/json")
                self._cors(); self.end_headers()
                self.wfile.write(json.dumps({"token": token, "ok": True}).encode())
            else:
                log("WARN", f"AUTH FAILURE — {self.client_address[0]}")
                self.send_json({"ok": False, "error": "invalid credentials"}, 401)
            return

        # ── UPLOAD ──
        if path == "/api/upload":
            if not self._authed():
                self.send_json({"error":"unauthorized"}, 401); return

            content_type = self.headers.get("Content-Type", "")
            content_len  = int(self.headers.get("Content-Length", 0))

            if content_len > CONFIG["max_upload"]:
                self.send_json({"error":"file too large"}, 413); return

            # Parse destination dir from query string
            qs    = parse_qs(parsed.query)
            dest_rel = qs.get("dir", [""])[0]
            dest  = safe_path(dest_rel) or ROOT
            if not dest.is_dir():
                self.send_json({"error":"invalid destination"}, 400); return

            # Multipart boundary
            boundary = None
            for part in content_type.split(";"):
                part = part.strip()
                if part.startswith("boundary="):
                    boundary = part[9:].encode()

            if not boundary:
                self.send_json({"error":"bad request — no boundary"}, 400); return

            # Read body
            raw = self.rfile.read(content_len)
            # Find filename
            fname = "upload_" + str(int(time.time()))
            for line in raw.split(b"\r\n"):
                if b"filename=" in line:
                    fname = line.split(b'filename="')[1].split(b'"')[0].decode()
                    break

            # Extract file data (after double CRLF)
            parts = raw.split(b"\r\n\r\n", 1)
            if len(parts) < 2:
                self.send_json({"error":"malformed multipart"}, 400); return
            file_data = parts[1].rsplit(b"\r\n", 1)[0]  # strip trailing boundary

            out = dest / fname
            out.write_bytes(file_data)
            log("BEAM", f"UPLOAD  {fname}  ({human_size(len(file_data))})  ← {self.client_address[0]}")
            self.send_json({"ok": True, "name": fname, "size": len(file_data)}); return

        # ── DELETE ──
        if path == "/api/delete":
            if not self._authed():
                self.send_json({"error":"unauthorized"}, 401); return
            length = int(self.headers.get("Content-Length", 0))
            body   = json.loads(self.rfile.read(length))
            rel    = body.get("path","")
            p      = safe_path(rel)
            if not p or not p.exists():
                self.send_json({"error":"not found"}, 404); return
            if p.is_dir():
                shutil.rmtree(p)
            else:
                p.unlink()
            log("WARN", f"DELETE  {p.name}")
            self.send_json({"ok": True}); return

        # ── MKDIR ──
        if path == "/api/mkdir":
            if not self._authed():
                self.send_json({"error":"unauthorized"}, 401); return
            length = int(self.headers.get("Content-Length", 0))
            body   = json.loads(self.rfile.read(length))
            p = safe_path(body.get("path","new_folder"))
            if p:
                p.mkdir(parents=True, exist_ok=True)
                self.send_json({"ok": True}); return
            self.send_json({"error":"invalid path"}, 400); return

        self.send_json({"error":"not found"}, 404)


# ──────────────────────────────────────────────
#  LOCALTUNNEL  (internet access)
# ──────────────────────────────────────────────
def start_tunnel(port: int):
    try:
        result = subprocess.Popen(
            ["lt", "--port", str(port)],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True
        )
        for line in result.stdout:
            if "https://" in line:
                url = line.strip().split()[-1]
                log("OK", f"TUNNEL ONLINE → {url}")
                print(f"\n  {C['gold']}◈ INTERNET URL:{C['reset']}  {C['cyan']}{url}{C['reset']}\n")
                return url
    except FileNotFoundError:
        log("WARN", "localtunnel not installed. Run: npm install -g localtunnel")


# ──────────────────────────────────────────────
#  STARTUP BANNER
# ──────────────────────────────────────────────
def banner():
    ip = socket.gethostbyname(socket.gethostname())
    print(f"""
{C['cyan']}
  ███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗
  ████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝
  ██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗
  ██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║
  ██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║
  ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝
{C['reset']}
  {C['gold']}PERSONAL FILE MATRIX  v{NEXUS_VERSION}{C['reset']}
  ─────────────────────────────────────
  {C['dim']}Serving:{C['reset']}  {C['cyan']}{ROOT}{C['reset']}
  {C['dim']}Local:  {C['reset']}  {C['green']}http://{ip}:{CONFIG['port']}{C['reset']}
  {C['dim']}All:    {C['reset']}  {C['green']}http://0.0.0.0:{CONFIG['port']}{C['reset']}
  ─────────────────────────────────────
  {C['dim']}Open the URL above in any browser.{C['reset']}
  {C['dim']}Ctrl+C to shutdown.{C['reset']}
""")


# ──────────────────────────────────────────────
#  MAIN
# ──────────────────────────────────────────────
def main():
    banner()
    # Validate config
    if CONFIG["secret_key"] == "CHANGE_THIS_TO_A_LONG_RANDOM_STRING_NOW":
        log("WARN", "secret_key is default — CHANGE IT in CONFIG before exposing to internet!")
    if CONFIG["password"] == "CHANGE_THIS_PASSWORD":
        log("WARN", "password is default — CHANGE IT in CONFIG before use!")

    if CONFIG["tunnel"]:
        threading.Thread(target=start_tunnel, args=(CONFIG["port"],), daemon=True).start()

    server = HTTPServer((CONFIG["host"], CONFIG["port"]), NexusHandler)

    if CONFIG["use_ssl"]:
        import ssl
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain("cert.pem", "key.pem")
        server.socket = ctx.wrap_socket(server.socket, server_side=True)
        log("OK", "TLS enabled")

    log("OK", f"NEXUS ONLINE — port {CONFIG['port']}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log("INFO", "NEXUS SHUTDOWN — goodbye")
        server.shutdown()


if __name__ == "__main__":
    main()
